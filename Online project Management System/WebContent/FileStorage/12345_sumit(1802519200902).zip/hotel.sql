-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 23, 2018 at 10:33 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `expr`
--

DROP TABLE IF EXISTS `expr`;
CREATE TABLE IF NOT EXISTS `expr` (
  `username` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `room` varchar(200) NOT NULL,
  `price` varchar(200) NOT NULL,
  `facil` varchar(200) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expr`
--

INSERT INTO `expr` (`username`, `location`, `room`, `price`, `facil`) VALUES
('sumit', '0', 'Rooms were big and had plenty of fun', 'nope just 2000rs', 'hot water, ac '),
('', '0', '', '', ''),
('vijay', 'pune', 'Rooms were big and had plenty of fun', 'nope just 2000rs', 'hot water, ac '),
('roshani', 'pune', 'Rooms were big and had plenty of fun', 'nope just 2000rs', 'hot water, ac ');

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

DROP TABLE IF EXISTS `reg`;
CREATE TABLE IF NOT EXISTS `reg` (
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `pwd` varchar(10) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`name`, `email`, `location`, `username`, `pwd`) VALUES
('sumit', 'shb@jnjk', 'Kolhapur', 'sumit', '1234'),
('vijay', 'vijay@gmail.com', 'up', 'vijay', '789'),
('roshani', 'hdhcdb', 'pune', 'roshani', '456');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
