<?php
  $name = $_POST['name']; 
	$room = $_POST['room'];
	$price = $_POST['price'];
	$fac = $_POST['fac'];
	$conn = mysqli_connect('localhost','root','','hotel');


if($conn){
	$sql="insert into exp values('$room','$room','$price','$fac')"; 
 
		$qry=mysqli_query($conn,$sql);
    if($qry)
    {
     echo "inserted";
     header('location:home.php');
    }
   else
  { 
	echo "not insertesd";
	header('location:exp.php');
  }
}

else{

	echo "connection error";
	header('location:exp.php');
}

 

?>

 ?>
