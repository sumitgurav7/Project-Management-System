<!DOCTYPE html>
<html>
<head>
	<title>Share Your Experience</title>
</head>
<body>
	<div>
	<h1>How was your Hotel Experience</h1>
	<form action="expr.php" method="post">
	    <input type="text" name="name" placeholder="name">
		<input type="text" name="room" placeholder="type of room">
		<input type="number" name="price" placeholder="price of room">
		<input type="text" name="fac" placeholder="facilities">
		<input type="text" name="location" placeholder="location">		
		 <button type="submit" value="submit">submit</button>
     </form>
     </div>
</body>
</html>