<<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Travel Log</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
	<div>
		<h1>Hotel  Registration</h1>
    <form action="reg.php" method="post">
    	<input type="text" name="name" placeholder="name">
    	<input type="text" name="location" placeholder="location">
    	<input type="text" name="email" placeholder="email">
    	<input type="text" name="username" placeholder="username">
    	<input type="text" name="pwd" placeholder="password">
    	<button type="submit" value="submit">submit</button>
	</form>    
    </div>
    <div>
    	<h1>Log In</h1>
		<form action="login.php" method="post">
			<input type="text" name="username" placeholder="username">
			<input type="text" name="pwd" placeholder="password">
			<button type="submit" value="login">Log In</button>
		</form>    	
    </div>
    <div>
        <h1>show exp</h1>
        <form action="show.php" method="post">
        <input type="text" name="name" placeholder="name">
            <button type="submit" value="submit">Submit</button>

        </form>
    </div>
    
</body>
</html>