<?php 
	$name = $_POST['name'];
	$location = $_POST['location'];
	$email = $_POST['email'];
	$username = $_POST['username'];
	$pwd = $_POST['pwd'];
	$conn = mysqli_connect('localhost','root','','hotel');


if($conn){
	$sql="insert into reg values('$name','$location','$email','$username','$pwd')"; 
 
		$qry=mysqli_query($conn,$sql);
    if($qry)
    {
     echo "inserted";
    }
   else
  { 
	echo "not insertesd";
  }
}

else{

	echo "connection error";
}

 header('location:home.php');

?>

 ?>
