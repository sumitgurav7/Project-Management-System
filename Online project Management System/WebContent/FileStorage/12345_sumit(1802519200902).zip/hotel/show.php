<?php
$name = $_POST['name'];
$conn=mysqli_connect('localhost','root','','hotel');

if($conn){
$sql="select * from exp where  name='" . $name . "';
$qry=mysqli_query($conn,$sql);
echo $qry;
while($row=mysqli_fetch_assoc($qry))
{
echo "<tr><td>'".$row['name']."'</td><td>'".$row['room']."'</td><td>'".$row['price']."'</td><td>'".$row['fac']."'</td><td>'".$row['location']."'</td></tr>";
}
}
else{

	echo error;
}

  ?>