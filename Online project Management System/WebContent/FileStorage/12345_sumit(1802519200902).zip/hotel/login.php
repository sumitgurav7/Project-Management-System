<?php 
	
	$username = $_POST['username'];
	$pwd = $_POST['pwd'];
	$conn = mysqli_connect('localhost','root','','hotel');


if($conn){
	$sql="select * from reg where username='" . $username . "' && pwd='" . $pwd . "'";

 
		$qry=mysqli_query($conn,$sql);
		$row=mysqli_fetch_assoc($qry);
		// $check=$row['username'];
    if($row['username'])
    {
     echo "logged in";
     header('location:exp.php');
    }
   else
  { 
	echo "Credentials not correct";
	header('location:home.php');
  }
}

else{

	echo "connection error";
	header('location:home.php');
}

 

?>

 ?>
