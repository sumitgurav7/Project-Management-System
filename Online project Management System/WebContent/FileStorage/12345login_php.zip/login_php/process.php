<?php
$username = $_POST["username"];
$password = $_POST["password"];


$con=mysqli_connect("localhost","root","","registration");

//query the database for user

$result = mysqli_query($con,"select * from form where username='$username' and password='$password'");
$row=mysqli_fetch_array($result);
if($row['username']==$username && $row['password']==$password)
{
	echo "login successfull !! welcome"." :".$_POST['username'];
}else{

echo"failed to login";
}

?>

<?php

// define variables and set to empty values
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

try{
    $conn = mysqli_connect($servername,$username,$password,$dbname);
    echo("successfull connection ");
}catch(MySQLi_sql_Exception $ex)
{
echo("error in connection");

}
if (isset($_POST['submit'])) {
  $Room_Type = $_POST["Room_Type"];
  $Price = $_POST["Price"];
  $Facilities = $_POST["Facilities"];

  $register_query = "INSERT INTO `des`(`Room_Type`, `Price`, `Facilities`) VALUES ('$Room_Type','$Price','$Facilities')";
  try{
    $register_result = mysqli_query($conn,$register_query);
    if ($register_result)
     {
      if(mysqli_affected_rows($conn)>0)
      {

        echo("registration successful");
      }
      else{
        echo("error in registration");
      }
    }
  }catch(Exception $ex){
      echo("error".$ex->getMessage());
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Travel experiences</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h1>Travel experiences</h1>
	<hr> 
	<div id="ab">
	<p>Room_Type:
	<input type="text" placeholder="Room_Type" name="Room_Type"/></p>
	<p>Price:
	<input type="text" name="Price"/>
	</p>
	<p>
		Facilities:
		<input type="text" name="Facilities"/>
	</p>
	<p>
		<input type="submit" value="submit" id="btn">
	</p>
</div>
</body>
<div>
	<hr>
	<p>&copy; Travelogue <?php echo date("M Y"); ?></p>
</div>
</html>

