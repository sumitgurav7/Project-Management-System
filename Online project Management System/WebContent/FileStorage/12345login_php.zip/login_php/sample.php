<!DOCTYPE html>  
<html>
<head>
</head>
<link rel="stylesheet" type="text/css" href="style.css">
<body>  
  <?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

try{
    $conn = mysqli_connect($servername,$username,$password,$dbname);
    echo("successfull connection ");
}catch(MySQLi_sql_Exception $ex)
{
echo("error in connection");

}
if (isset($_POST['submit'])) {
  $name = $_POST["name"];
  $location = $_POST["location"];
  $email = $_POST["email"];
  $username = $_POST["username"];
  $password = $_POST["password"];
  $register_query = "INSERT INTO `form`(`name`, `email`, `hometown`, `username`, `password`) VALUES ('$name','$email','$hometown','$username','$password')";
  try{
    $register_result = mysqli_query($conn,$register_query);
    if ($register_result)
     {
      if(mysqli_affected_rows($conn)>0)
      {

        echo("registration successful");
      }
      else{
        echo("error in registration");
      }
    }
  }catch(Exception $ex){
      echo("error".$ex->getMessage());
}
}
?>



<h2>Registration Page</h2>
<hr>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  <div id="ab">
  Name: <input type="text" name="name">
  <br><br>
  location: <input type="text" name="location">
  <br><br>
  E-mail: <input type="text" name="E-mail">
  <br><br>
  Username: <input type="text" name="username">
  <br><br>
  Password:<input type="password" name="password">
  <br><br>
  <input type="submit" name="submit" id="btn" value="Submit">  
  
</form>
</div>
<div>
  <hr>
  <p>&copy;Hotel Booking  <?php echo date("M Y"); ?></p>

  </div>
</body>
</html>