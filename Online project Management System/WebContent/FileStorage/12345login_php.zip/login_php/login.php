<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
	<h1>Login Page</h1>
	<hr> 
	<div id="frm">
		<form action="process.php" method="POST">
			<p>
				<input type="text" placeholder="Username" id="user" name="username"/>

			</p>
			<p>
				
				<input type="password" placeholder="Password" id="pass" name="password"/>
			</p>
			<p>
				<a href="http://localhost/login_php/sample.php">New User</a> Register here
				<a href="localhost/login/desc.php"><input type="submit" id="btn" name="submit" value="Login" onclick="window.location = 'http://localhost/login_php/desc.php';" / ></a>
				
			</p>
		</form>
	</div>
	<div>
	<hr>
	<p>&copy; Hotel Booking <?php echo date("M Y"); ?></p>

	</div>

</body>
</html>