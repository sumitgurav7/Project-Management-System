package com.exam;

public class Student {
	private String city;
	private String name;
	private String mobile;
	
	
	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	@Override
	public String toString() {
		return "Student [city=" + city + ", name=" + name + ", mobile=" + mobile + "]";
	}


	
}
