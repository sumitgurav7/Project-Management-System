package com.exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




public class ServiceLayer {

	

	public static List<Student> freak(String category) {
		// TODO Auto-generated method stub
		String city = category;
		
		List<Student> x =new ArrayList<>();
		String sqlCmd ="select * from persons where city=?";
		try {
			Connection con = getConnection();
			if( con != null)
					System.out.println("connection is working");
			
			 PreparedStatement stmt = con.prepareStatement(sqlCmd);
		     stmt.setString(1, city);
			 ResultSet rs  =stmt.executeQuery();
			Student s = null;
			while(rs.next())
			{
				s= new Student();
					s.setCity(rs.getString("city"));
					s.setName(rs.getString("name"));
					s.setMobile(rs.getString("mobile"));
					x.add(s);
				
				
			}
			
			rs.close();  
			
		
			con.close();
		} catch (FreakyDatabaseProblem e) {
			// TODO Auto-generated catch block
			x=null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return x;
	}

	private static Connection getConnection() throws FreakyDatabaseProblem {
		// TODO Auto-generated method stub
		Connection  conn=null;
		 final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		   final String DB_URL = "jdbc:mysql://localhost/java";
		   final String USER = "root";
		   final String PASS = "";
		
			try {
				Class.forName(JDBC_DRIVER);
				    conn = DriverManager.getConnection(DB_URL, USER, PASS);
				    System.out.println("hopefully no injuries");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw new FreakyDatabaseProblem();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new FreakyDatabaseProblem();
			}
		
		
		return conn;
	}

}

