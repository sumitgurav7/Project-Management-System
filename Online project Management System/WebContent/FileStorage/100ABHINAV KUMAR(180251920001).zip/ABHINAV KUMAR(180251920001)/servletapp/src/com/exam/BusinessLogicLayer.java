package com.exam;

import java.util.List;

import javax.servlet.http.HttpServletRequest;




public class BusinessLogicLayer {



	public String scrap(HttpServletRequest request) {
		// TODO Auto-generated method stub
String pageName="/WEB-INF/error.jsp";
		
		String whateveritis = request.getParameter("HR");
		
		List<Student> itemList = ServiceLayer.freak(whateveritis);
		if(itemList.size()>0)
		{
			
		
		request.setAttribute("k1", itemList);
		pageName="index.jsp";
		}
		else
		{
			request.setAttribute("k1", "no data found <br> try again");
		}
		return pageName;
	}

}
