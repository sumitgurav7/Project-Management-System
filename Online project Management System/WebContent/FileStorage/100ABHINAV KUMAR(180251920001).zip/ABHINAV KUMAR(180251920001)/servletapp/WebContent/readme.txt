NAME: ABHINAV KUMAR
PNR : 180251920001


database Queries

==================================================================
Question 2


CREATE TABLE `persons` (
  `city` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` varchar(10) NOT NULL
)

----------------------------------------------------------------



INSERT INTO `persons` (`city`, `name`, `mobile`) VALUES
('banglore', 'abhinav', 'redmi y2'),
('banglore', 'shruti', 'one plus'),
('pune', 'abhishek', 'apple'),
('pune', 'preeti', 'samsung'),
('ranchi', 'navita', 'samsung')
