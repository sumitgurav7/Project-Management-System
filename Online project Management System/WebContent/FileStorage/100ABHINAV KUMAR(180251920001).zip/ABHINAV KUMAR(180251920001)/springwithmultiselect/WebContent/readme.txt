
NAME: ABHINAV KUMAR
PNR : 180251920001

database Queries
Question 1


CREATE TABLE `cp` (
  `city` varchar(20) NOT NULL,
  `area` varchar(20) NOT NULL,
  `pincode` int(10)
)

-------------------------------------------------------------

INSERT INTO `cp` (`city`, `area`, `pincode`) VALUES ('banglore', 'E-City', '560100'), ('pune', 'hinjawadi', '825301');

==================================================================
