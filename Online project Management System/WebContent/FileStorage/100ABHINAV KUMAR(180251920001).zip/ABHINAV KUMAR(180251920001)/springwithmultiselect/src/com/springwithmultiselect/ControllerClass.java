package com.springwithmultiselect;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class ControllerClass {
	
	private ServiceLayer s;
	
	@Autowired
	public void setS(ServiceLayer s) {
		this.s = s;
	}
	
	 public ControllerClass() {
		// TODO Auto-generated constructor stub
		System.out.println("never have hope in programming");
	}

	@RequestMapping("/click")
	public ModelAndView fun1()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/WEB-INF/studentinfo.jsp");
		return mv;
		
	}
	@RequestMapping("/sclGetInfo")
	public ModelAndView getStudentDetail(@RequestParam("schlname")String city)
	{
		ModelAndView mv = new ModelAndView();
		List<Student> st =s.getStudentInfoBaswedOncity(city);
		if(st.size()>0)
		{
			mv.addObject("k1","city : "+ city);
			mv.addObject("k2", st);
		}
		else
		{
			mv.addObject("k1", city +" not found ");
		}
		System.out.println("notice boards was working");
		mv.setViewName("/WEB-INF/studentinfo.jsp");
		return mv;
						
	}
}
