package com.springwithmultiselect;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class DaoLayer {
	
	private JdbcTemplate t;
	@Autowired
	public void setT(JdbcTemplate t) {
		this.t = t;
	}

	public List<Student> getAllStudentFromDB(String city) {
		// TODO Auto-generated method stub
		
		List<Student> st = null;
		String cmd = "select *from cp where city=?";
		Object x[] = {city};
		RowMapper<Student> rm = new getAllStudentInfo();
		st = t.query(cmd, x,rm);
		return st ;
	}

}
