package com.springwithmultiselect;



public class Student {

	int pincode;
	String city,area;
	
	public Student(int pincode, String city, String area) {
		super();
		this.pincode = pincode;
		this.city = city;
		this.area = area;
	}


	
	
	public int getPincode() {
		return pincode;
	}




	public void setPincode(int pincode) {
		this.pincode = pincode;
	}




	public String getCity() {
		return city;
	}




	public void setCity(String city) {
		this.city = city;
	}




	public String getArea() {
		return area;
	}




	public void setArea(String area) {
		this.area = area;
	}




	public Student(String area,int pincode)
	{
		super();
		this.area = area;
		this. pincode =  pincode;
	}


}
