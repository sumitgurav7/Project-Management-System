package com.springwithmultiselect;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ServiceLayer {
	
	private DaoLayer dl;
	@Autowired
	public void setDl(DaoLayer dl) {
		this.dl = dl;
	}

	public List<Student> getStudentInfoBaswedOncity(String city) {
		// TODO Auto-generated method stub
		
		return dl.getAllStudentFromDB(city);
	}



	

}
