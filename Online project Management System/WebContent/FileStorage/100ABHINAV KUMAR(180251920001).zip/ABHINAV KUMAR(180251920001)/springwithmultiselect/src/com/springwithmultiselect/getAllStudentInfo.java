package com.springwithmultiselect;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class getAllStudentInfo implements RowMapper<Student> {

	@Override
	public Student mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		int pincode = arg0.getInt("pincode");
		String area =arg0.getString("area");
		return new Student(area,pincode);
		
		
	}

}
