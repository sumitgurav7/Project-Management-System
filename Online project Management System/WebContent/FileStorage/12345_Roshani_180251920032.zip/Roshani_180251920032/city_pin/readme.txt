Author Roshani Kinge
roll : 180251920032

sql file to import has been given above please check the same

CREATE TABLE IF NOT EXISTS `cp` (
  `city` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL,
  `pincode` int(50) NOT NULL,
  PRIMARY KEY (`pincode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



INSERT INTO `cp` (`city`, `area`, `pincode`) VALUES ('pune', 'katraj', '410038');
INSERT INTO `cp` (`city`, `area`, `pincode`) VALUES ('pune', 'nigdi', '410044');
INSERT INTO `cp` (`city`, `area`, `pincode`) VALUES ('banglore', 'electronic city 1', '560100');