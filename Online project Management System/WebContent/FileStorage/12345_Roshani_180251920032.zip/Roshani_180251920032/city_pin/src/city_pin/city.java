package city_pin;

public class city {

	String city;
	String area;
	int pincode;
	
	public city(String city, String area, int pincode) {
		super();
		this.city = city;
		this.area = area;
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "city=" + city + ", area=" + area + ", pincode=" + pincode ;
	}
	
	
	
}
