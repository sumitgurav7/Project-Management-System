package city_pin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class serviceLa {

	private DAOl dl;
	
	
	@Autowired
	public void setDl(DAOl dl) {
		this.dl = dl;
	}

	public serviceLa() {
		// TODO Auto-generated constructor stub
		System.out.println("in serv lay");
		
	}

	public List<city> getDataDao(String city) {
		// TODO Auto-generated method stub
		
		
		return dl.getDBdata(city);
	}
}
