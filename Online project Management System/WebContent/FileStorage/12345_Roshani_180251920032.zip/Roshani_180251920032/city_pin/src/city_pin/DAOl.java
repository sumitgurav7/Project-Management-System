package city_pin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class DAOl {

	private JdbcTemplate t;

	@Autowired
	public void setT(JdbcTemplate t) {
		this.t = t;
	}

	public List<city> getDBdata(String city) {
		// TODO Auto-generated method stub
		
		
		String cmd = "SELECT * FROM `cp` WHERE city = ?";
		Object x[] = {city};
		RowMapper<city> rm = new getItem();
		List<city> list =t.query(cmd, x,rm);
		if(list.size()>0)
				return list;
		else
			return null;
		
		
	}
	
	
	
}
