package city_pin;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class getItem implements RowMapper<city> {

	@Override
	public city mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		String city = arg0.getString("city");
		String area = arg0.getString("area");
		int pincode = arg0.getInt("pincode");
		
		return new city(city, area, pincode);
	}

}
