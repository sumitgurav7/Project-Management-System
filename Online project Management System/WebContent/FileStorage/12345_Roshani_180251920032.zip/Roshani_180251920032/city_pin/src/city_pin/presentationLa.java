package city_pin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;




@Controller
public class presentationLa {
	
	private serviceLa sl;
	
	public presentationLa() {
		// TODO Auto-generated constructor stub
		System.out.println("in presentation layer");
	}
	
	@Autowired
	public void setSl(serviceLa sl) {
		this.sl = sl;
	}
	
	@RequestMapping("/pincode")
	public ModelAndView getPinfromserv(@RequestParam("city") String city)
	{
		
		ModelAndView mv = new ModelAndView();
		
		System.out.println("in mvc");
		List<city> li = sl.getDataDao(city);
		
		if(li != null)
		{
			System.out.println("in if loop");
			mv.addObject("k1", li);
			mv.setViewName("/index.jsp");
		}
		else
		{
			mv.setViewName("/err.jsp");
		}
		System.out.println("in mvc");
	
		return mv;
		
	}
	
}
