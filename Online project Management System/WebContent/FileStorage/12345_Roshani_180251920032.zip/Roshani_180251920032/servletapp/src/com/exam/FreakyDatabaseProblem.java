package com.exam;

public class FreakyDatabaseProblem extends Exception {

}
