NAME: Roshani Kinge
PNR : 180251920032


database Queries

==================================================================
Question 2


CREATE TABLE `persons` (
  `city` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` varchar(10) NOT NULL
)

----------------------------------------------------------------



INSERT INTO `persons` (`city`, `name`, `mobile`) VALUES
('banglore', 'roshani', 'lenovo a7000'),
('banglore', 'piyush', 'lenovo a6000'),
('pune', 'sumit', 'one plus 6T'),
('pune', 'preeti', 'samsung'),
('ranchi', 'navita', 'samsung')
